from django.contrib import admin
from .models import Library

# Register your models here.
admin.site.register(Library)