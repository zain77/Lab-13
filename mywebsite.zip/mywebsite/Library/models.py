from django.db import models

class Library(models.Model):
    author=models.CharField(max_length=250,default='SOME STRONG')
    name=models.CharField(max_length=250,default='SOME STRONG')
    category=models.CharField(max_length=250,default='SOME STRONG')
# Create your models here.
